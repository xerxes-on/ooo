#!/bin/bash
# Helper: Look up model definition and fields from Odoo reference
# Usage: ./lookup-model.sh <model_name> [version]
# Example: ./lookup-model.sh res.partner 18
# Example: ./lookup-model.sh sale.order

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

MODEL_NAME="$1"
VERSION="${2:-18}"
REFERENCE_DIR="$PROJECT_ROOT/reference/odoo-$VERSION"

if [ -z "$MODEL_NAME" ]; then
    echo "Usage: $0 <model_name> [version]"
    echo "Example: $0 res.partner 18"
    echo "Example: $0 sale.order"
    exit 1
fi

if [ ! -d "$REFERENCE_DIR" ]; then
    echo "ERROR: Reference for Odoo $VERSION not found at $REFERENCE_DIR"
    echo "Run: .claude/hooks/setup-odoo-reference.sh $VERSION"
    exit 1
fi

# Convert model name to file pattern
MODEL_UNDERSCORE=$(echo "$MODEL_NAME" | tr '.' '_')

echo "=== Looking up '$MODEL_NAME' in Odoo $VERSION ==="
echo ""

# Find model file
MODEL_FILE=""

# First check in base (for core models)
BASE_FILE=$(find "$REFERENCE_DIR/odoo/addons/base" -name "${MODEL_UNDERSCORE}.py" 2>/dev/null | head -1)
if [ -n "$BASE_FILE" ]; then
    MODEL_FILE="$BASE_FILE"
fi

# If not found, search by _name definition
if [ -z "$MODEL_FILE" ]; then
    MODEL_FILE=$(find "$REFERENCE_DIR/odoo/addons" "$REFERENCE_DIR/addons" -name "*.py" \
        -exec grep -l "_name[[:space:]]*=[[:space:]]*['\"]$MODEL_NAME['\"]" {} \; 2>/dev/null | head -1)
fi

if [ -z "$MODEL_FILE" ]; then
    echo "Model '$MODEL_NAME' not found in Odoo $VERSION reference"
    exit 1
fi

echo "Model file: ${MODEL_FILE#$PROJECT_ROOT/}"
echo ""

# Extract module name
MODULE_PATH=$(echo "$MODEL_FILE" | sed "s|$REFERENCE_DIR/||" | cut -d'/' -f1-2)
echo "Module: $MODULE_PATH"
echo ""

# Show model class definition
echo "=== Model Definition ==="
grep -n "class\|_name\|_inherit\|_description" "$MODEL_FILE" | head -10
echo ""

# Show fields
echo "=== Fields (first 30) ==="
grep -n "fields\." "$MODEL_FILE" | head -30
echo ""

# Count fields
FIELD_COUNT=$(grep -c "fields\." "$MODEL_FILE" 2>/dev/null || echo "0")
echo "Total fields: ~$FIELD_COUNT"
echo ""

# Show related computed fields
echo "=== Computed Fields ==="
grep -n "compute=" "$MODEL_FILE" | head -10
echo ""

# Compare with other version if available
OTHER_VERSION=$([[ "$VERSION" == "18" ]] && echo "17" || echo "18")
OTHER_REF="$PROJECT_ROOT/reference/odoo-$OTHER_VERSION"
if [ -d "$OTHER_REF" ]; then
    OTHER_FILE=$(find "$OTHER_REF/odoo/addons/base" -name "${MODEL_UNDERSCORE}.py" 2>/dev/null | head -1)
    if [ -z "$OTHER_FILE" ]; then
        OTHER_FILE=$(find "$OTHER_REF/odoo/addons" "$OTHER_REF/addons" -name "*.py" \
            -exec grep -l "_name[[:space:]]*=[[:space:]]*['\"]$MODEL_NAME['\"]" {} \; 2>/dev/null | head -1)
    fi
    if [ -n "$OTHER_FILE" ]; then
        OTHER_COUNT=$(grep -c "fields\." "$OTHER_FILE" 2>/dev/null || echo "0")
        echo "=== Version Comparison ==="
        echo "Odoo $VERSION: ~$FIELD_COUNT fields"
        echo "Odoo $OTHER_VERSION: ~$OTHER_COUNT fields"
    fi
fi
