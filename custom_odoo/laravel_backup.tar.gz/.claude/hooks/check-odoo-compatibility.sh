#!/bin/bash
# Consolidated Odoo Compatibility Check Hook
# Auto-detects target Odoo version and validates against reference
# Compatible with macOS and Linux

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
WORKSPACE_DIR="$PROJECT_ROOT/module_workspace"
REFERENCE_BASE="$PROJECT_ROOT/reference"

# Supported Odoo versions (add more as needed)
SUPPORTED_VERSIONS=("14" "15" "16" "17" "18" "19")

# Version-specific breaking changes
# Format: "min_version:max_version:type:pattern:replacement:description"
BREAKING_CHANGES=(
    # tree -> list change in Odoo 18+
    "18:99:xml:<tree:<list:Use <list> instead of <tree> in views"
    "18:99:xml:type=\"tree\":type=\"list\":Use type=\"list\" instead of type=\"tree\""
    # company_id -> company_ids in Odoo 18+ for specific models
    "18:99:field:company_id:company_ids:res.partner/res.users company_id changed to company_ids (Many2many)"
)

ERRORS_FOUND=0
WARNINGS_FOUND=0

# Check if module_workspace exists
if [ ! -d "$WORKSPACE_DIR" ]; then
    exit 0
fi

# Function to detect Odoo version from manifest
detect_version() {
    local manifest_file="$1"
    if [ -f "$manifest_file" ]; then
        # Extract version like "18.0.1.0.0" and get major version
        local version=$(grep -o "version.*['\"][0-9]*\.[0-9]*" "$manifest_file" | grep -o "[0-9]*\.[0-9]*" | head -1 | cut -d'.' -f1)
        echo "$version"
    fi
}

# Function to find model file in reference
find_model_file() {
    local model_name="$1"
    local ref_dir="$2"

    if [ ! -d "$ref_dir" ]; then
        return
    fi

    local model_underscore=$(echo "$model_name" | tr '.' '_')

    # First try base (core models)
    local base_file=$(find "$ref_dir/odoo/addons/base" -name "${model_underscore}.py" 2>/dev/null | head -1)
    if [ -n "$base_file" ]; then
        echo "$base_file"
        return
    fi

    # Search by _name definition
    find "$ref_dir/odoo/addons" "$ref_dir/addons" -name "*.py" \
        -exec grep -l "_name[[:space:]]*=[[:space:]]*['\"]$model_name['\"]" {} \; 2>/dev/null | head -1
}

# Function to check if a pattern exists in reference
check_pattern_in_reference() {
    local pattern="$1"
    local ref_dir="$2"
    local file_type="$3"

    if [ ! -d "$ref_dir" ]; then
        return 1
    fi

    case "$file_type" in
        xml)
            grep -rq "$pattern" "$ref_dir/addons" --include="*.xml" 2>/dev/null
            ;;
        py)
            grep -rq "$pattern" "$ref_dir/addons" --include="*.py" 2>/dev/null
            ;;
        *)
            grep -rq "$pattern" "$ref_dir/addons" 2>/dev/null
            ;;
    esac
}

# Function to count pattern usage in reference
count_pattern_in_reference() {
    local pattern="$1"
    local ref_dir="$2"
    local file_type="$3"

    if [ ! -d "$ref_dir" ]; then
        echo "N/A"
        return
    fi

    case "$file_type" in
        xml)
            grep -r "$pattern" "$ref_dir/addons" --include="*.xml" 2>/dev/null | wc -l | tr -d ' '
            ;;
        py)
            grep -r "$pattern" "$ref_dir/addons" --include="*.py" 2>/dev/null | wc -l | tr -d ' '
            ;;
        *)
            grep -r "$pattern" "$ref_dir/addons" 2>/dev/null | wc -l | tr -d ' '
            ;;
    esac
}

echo "========================================"
echo "  Odoo Compatibility Check"
echo "========================================"
echo ""

# Find all modules in workspace
MODULES=$(find "$WORKSPACE_DIR" -name "__manifest__.py" -type f 2>/dev/null)

if [ -z "$MODULES" ]; then
    echo "No Odoo modules found in module_workspace/"
    exit 0
fi

# Process each module
for manifest in $MODULES; do
    MODULE_DIR=$(dirname "$manifest")
    MODULE_NAME=$(basename "$MODULE_DIR")

    # Detect version
    VERSION=$(detect_version "$manifest")
    if [ -z "$VERSION" ]; then
        echo "WARNING: Could not detect Odoo version for $MODULE_NAME"
        echo "  Please ensure __manifest__.py has a version like '18.0.1.0.0'"
        WARNINGS_FOUND=1
        VERSION="18"  # Default assumption
    fi

    REFERENCE_DIR="$REFERENCE_BASE/odoo-$VERSION"

    echo "Module: $MODULE_NAME"
    echo "  Target Odoo version: $VERSION"
    echo "  Reference: ${REFERENCE_DIR#$PROJECT_ROOT/}"

    # Check if reference exists
    if [ ! -d "$REFERENCE_DIR" ]; then
        echo "  WARNING: Reference for Odoo $VERSION not found!"
        echo "  Run: .claude/hooks/setup-odoo-reference.sh $VERSION"
        WARNINGS_FOUND=1
        echo ""
        continue
    fi

    echo ""

    # Apply version-specific checks
    for change in "${BREAKING_CHANGES[@]}"; do
        IFS=':' read -r min_ver max_ver check_type pattern replacement description <<< "$change"

        # Check if this change applies to the target version
        if [ "$VERSION" -ge "$min_ver" ] && [ "$VERSION" -le "$max_ver" ]; then
            case "$check_type" in
                xml)
                    # Check for deprecated XML patterns
                    FOUND=$(grep -rn "$pattern" "$MODULE_DIR" --include="*.xml" 2>/dev/null)
                    if [ -n "$FOUND" ]; then
                        echo "  ERROR: Deprecated pattern found for Odoo $VERSION+"
                        echo "    Pattern: $pattern"
                        echo "    Fix: $description"
                        echo "    Locations:"
                        echo "$FOUND" | while read -r line; do
                            echo "      - ${line#$PROJECT_ROOT/}"
                        done

                        # Show reference stats
                        OLD_COUNT=$(count_pattern_in_reference "$pattern" "$REFERENCE_DIR" "xml")
                        NEW_COUNT=$(count_pattern_in_reference "$replacement" "$REFERENCE_DIR" "xml")
                        echo "    Reference (Odoo $VERSION): '$pattern' usage: $OLD_COUNT, '$replacement' usage: $NEW_COUNT"
                        echo ""
                        ERRORS_FOUND=1
                    fi
                    ;;
                field)
                    # Check for deprecated field usage
                    FOUND=$(grep -rn "\b$pattern\b" "$MODULE_DIR" --include="*.py" --include="*.xml" 2>/dev/null | grep -v "$replacement")
                    if [ -n "$FOUND" ]; then
                        echo "  WARNING: Potentially deprecated field '$pattern'"
                        echo "    Note: $description"
                        echo "    Locations:"
                        echo "$FOUND" | head -5 | while read -r line; do
                            echo "      - ${line#$PROJECT_ROOT/}"
                        done
                        FOUND_COUNT=$(echo "$FOUND" | wc -l | tr -d ' ')
                        if [ "$FOUND_COUNT" -gt 5 ]; then
                            echo "      ... and $((FOUND_COUNT - 5)) more"
                        fi
                        echo ""
                        WARNINGS_FOUND=1
                    fi
                    ;;
            esac
        fi
    done

    # Check inherited models against reference
    INHERITS=$(find "$MODULE_DIR" -name "*.py" -exec grep -h "_inherit" {} \; 2>/dev/null | \
               sed -n "s/.*_inherit.*=[[:space:]]*['\"]\\([^'\"]*\\)['\"].*/\\1/p" | \
               sort -u)

    if [ -n "$INHERITS" ]; then
        echo "  Inherited Models:"
        for model in $INHERITS; do
            MODEL_FILE=$(find_model_file "$model" "$REFERENCE_DIR")
            if [ -n "$MODEL_FILE" ]; then
                FIELD_COUNT=$(grep -c "fields\." "$MODEL_FILE" 2>/dev/null || echo "0")
                echo "    - $model (${MODEL_FILE#$REFERENCE_DIR/}, ~$FIELD_COUNT fields)"
            else
                echo "    - $model (NOT FOUND in reference - check module dependencies)"
                WARNINGS_FOUND=1
            fi
        done
        echo ""
    fi
done

# Summary
echo "========================================"
echo "  Summary"
echo "========================================"
if [ $ERRORS_FOUND -eq 1 ]; then
    echo "FAILED: Compatibility errors detected. Please fix before proceeding."
    exit 1
elif [ $WARNINGS_FOUND -eq 1 ]; then
    echo "PASSED with WARNINGS: Review the warnings above."
    exit 0
else
    echo "PASSED: No compatibility issues detected."
    exit 0
fi
