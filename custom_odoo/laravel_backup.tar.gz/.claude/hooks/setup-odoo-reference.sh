#!/bin/bash
# Script to set up or refresh Odoo reference repositories
# Usage: ./setup-odoo-reference.sh [version|--list|--all]
# Example: ./setup-odoo-reference.sh 18       (single version)
# Example: ./setup-odoo-reference.sh --all    (all supported versions)
# Example: ./setup-odoo-reference.sh --list   (show available versions)

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
REFERENCE_DIR="$PROJECT_ROOT/reference"

# Supported Odoo versions (LTS and recent)
# Add more versions as needed
SUPPORTED_VERSIONS=("14" "15" "16" "17" "18" "19")

# Default versions to install (most commonly used)
DEFAULT_VERSIONS=("18" "19")

show_help() {
    echo "Odoo Reference Setup Script"
    echo ""
    echo "Usage: $0 [option|version]"
    echo ""
    echo "Options:"
    echo "  --help, -h    Show this help"
    echo "  --list, -l    List available and installed versions"
    echo "  --all, -a     Install all supported versions"
    echo "  <version>     Install specific version (e.g., 18, 17, 16)"
    echo ""
    echo "Without arguments, installs default versions: ${DEFAULT_VERSIONS[*]}"
    echo ""
    echo "Supported versions: ${SUPPORTED_VERSIONS[*]}"
}

list_versions() {
    echo "=== Odoo Reference Versions ==="
    echo ""
    echo "Supported versions: ${SUPPORTED_VERSIONS[*]}"
    echo ""
    echo "Installed:"
    for version in "${SUPPORTED_VERSIONS[@]}"; do
        local ref_path="$REFERENCE_DIR/odoo-$version"
        if [ -d "$ref_path" ]; then
            local addon_count=$(ls -1 "$ref_path/addons" 2>/dev/null | wc -l | tr -d ' ')
            local size=$(du -sh "$ref_path" 2>/dev/null | cut -f1)
            echo "  ✓ Odoo $version ($addon_count addons, $size)"
        else
            echo "  ✗ Odoo $version (not installed)"
        fi
    done
}

setup_version() {
    local version="$1"
    local ref_path="$REFERENCE_DIR/odoo-$version"

    # Validate version
    local valid=0
    for v in "${SUPPORTED_VERSIONS[@]}"; do
        if [ "$v" == "$version" ]; then
            valid=1
            break
        fi
    done

    if [ $valid -eq 0 ]; then
        echo "ERROR: Version '$version' is not supported"
        echo "Supported versions: ${SUPPORTED_VERSIONS[*]}"
        return 1
    fi

    echo ""
    echo "=== Setting up Odoo $version reference ==="

    if [ -d "$ref_path" ]; then
        echo "Updating existing reference..."
        cd "$ref_path" || return 1
        git fetch --depth 1 origin "$version.0" 2>/dev/null
        git reset --hard "origin/$version.0" 2>/dev/null
        git sparse-checkout set odoo/addons addons 2>/dev/null
        cd "$PROJECT_ROOT" || return 1
    else
        echo "Cloning Odoo $version (sparse checkout - addons only)..."
        git clone --depth 1 --branch "$version.0" --filter=blob:none --sparse \
            https://github.com/odoo/odoo.git "$ref_path" 2>&1 | grep -v "^remote:"
        cd "$ref_path" || return 1
        git sparse-checkout set odoo/addons addons 2>/dev/null
        cd "$PROJECT_ROOT" || return 1
    fi

    # Verify setup
    if [ -d "$ref_path/addons" ] && [ -d "$ref_path/odoo/addons" ]; then
        local addon_count=$(ls -1 "$ref_path/addons" 2>/dev/null | wc -l | tr -d ' ')
        local size=$(du -sh "$ref_path" 2>/dev/null | cut -f1)
        echo "SUCCESS: Odoo $version reference ready ($addon_count addons, $size)"
    else
        echo "ERROR: Failed to set up Odoo $version reference"
        return 1
    fi
}

# Create reference directory
mkdir -p "$REFERENCE_DIR"

# Process arguments
case "$1" in
    --help|-h)
        show_help
        exit 0
        ;;
    --list|-l)
        list_versions
        exit 0
        ;;
    --all|-a)
        echo "Installing all supported versions: ${SUPPORTED_VERSIONS[*]}"
        for version in "${SUPPORTED_VERSIONS[@]}"; do
            setup_version "$version"
        done
        ;;
    "")
        echo "Installing default versions: ${DEFAULT_VERSIONS[*]}"
        echo "(Use --all for all versions, or specify a version number)"
        for version in "${DEFAULT_VERSIONS[@]}"; do
            setup_version "$version"
        done
        ;;
    *)
        # Single version specified
        setup_version "$1"
        ;;
esac

echo ""
echo "=== Reference Setup Complete ==="
list_versions
